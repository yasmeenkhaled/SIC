const http = require('http');
const fs = require('fs');
const path = require('path');

// Define the directory where the files will be served from
const publicDir = path.join(__dirname, 'public');

// Create the HTTP server
const server = http.createServer((req, res) => {
    // Log the request method and URL
    console.log(`Request Method: ${req.method}, Request URL: ${req.url}`);

    // Serve the index.html file when the user visits the root URL
    if (req.url === '/' || req.url === '/index.html') {
        // Using asynchronous file reading method (fs.readFile)
        fs.readFile(path.join(publicDir, 'index.html'), 'utf8', (err, data) => {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/plain' });
                res.end('404 Not Found');
                console.log("Error reading file: Asynchronous Method");
            } else {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end(data);
                console.log("Served index.html: Asynchronous Method");
            }
        });
    } else {
        // Handle non-existing file requests
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
    }
});

// Start the server on port 3000
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
