const fs = require('fs');
const path = require('path');
const winston = require('winston');
require('winston-daily-rotate-file');

// Set up the logging with winston and daily rotate file
const logDir = 'logs'; // Directory where log files will be stored
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir); // Create the log directory if it doesn't exist
}

const transport = new winston.transports.DailyRotateFile({
    filename: `${logDir}/app-%DATE%.log`,
    datePattern: 'YYYY-MM-DD',
    zippedArchive: true,   // Optionally compress old logs
    maxSize: '20m',        // Max size of each log file
    maxFiles: '14d'        // Keep logs for the last 14 days
});

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ timestamp, level, message }) => {
            return `${timestamp} [${level.toUpperCase()}] - ${message}`;
        })
    ),
    transports: [transport],
});

// Asynchronous function to read, modify, and write files
const modifyFileContents = (inputFile, outputFile) => {
    // Read the contents of the file asynchronously
    fs.readFile(inputFile, 'utf8', (err, data) => {
        if (err) {
            logger.error(`Error reading file ${inputFile}: ${err.message}`);
            return;
        }

        logger.info(`Successfully read file ${inputFile}`);

        // Append a timestamp to the file's contents
        const modifiedData = `${data}\nTimestamp: ${new Date().toISOString()}\n`;

        // Write the modified contents to a new file asynchronously
        fs.writeFile(outputFile, modifiedData, 'utf8', (err) => {
            if (err) {
                logger.error(`Error writing to file ${outputFile}: ${err.message}`);
                return;
            }

            logger.info(`Successfully wrote to file ${outputFile}`);
        });
    });
};

// Example usage of the function
const inputFile = path.join(__dirname, 'input.txt');
const outputFile = path.join(__dirname, 'output.txt');

// Call the function to modify and write the contents
modifyFileContents(inputFile, outputFile);
